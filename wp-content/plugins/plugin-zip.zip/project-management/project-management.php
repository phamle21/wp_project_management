<?php

/**
 * Plugin Name: Project Management Plugin
 * Plugin URI: http://wordpress.test/
 * Description: This is a plugin for management projects
 * Version: 1.0
 * Author: Kha Nguyen
 * Author URI: http://wordpress.test
 * License: GPLv2
 **/
if (!defined('PROJECT_MANAGEMENT_PATH')) {
  define('PROJECT_MANAGEMENT_PATH', plugin_dir_path(__FILE__));
}

  require_once plugin_dir_path(__FILE__) . 'includes/pm-interface.php';
?>