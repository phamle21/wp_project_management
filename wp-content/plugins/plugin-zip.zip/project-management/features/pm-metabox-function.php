<?php

const PENDING = 'pending';
const IN_PROGRESS = 'in_progress';
const COMPLETED = 'completed';

add_action('add_meta_boxes', 'pm_add_new_project_metabox');

function pm_add_new_project_metabox()
{
    $id = 'add_new_project_metabox';
    $title = __('Project information', 'pm');
    $func_callback = 'pm_add_new_project_metabox_callback1';
    $arr_post_type = array('project');
    $context = 'advanced';
    $priority = 'low';
    add_meta_box($id, $title, $func_callback, $arr_post_type, $context, $priority);
}


function pm_list_members_metabox()
{
    $id = 'add_new_project_metabox';
    $title = __('Project information', 'pm');
    $func_callback = 'pm_add_new_project_metabox_callback1';
    $arr_post_type = array('project');
    $context = 'advanced';
    $priority = 'low';
    add_meta_box($id, $title, $func_callback, $arr_post_type, $context, $priority);
}

add_action('add_meta_boxes', 'pm_list_members_metabox');


function pm_add_new_project_metabox_callback1()
{
    include plugin_dir_path(__FILE__) . '../includes/form.php';
}


function filter_pm_validate_custom_metabox($data)
{
    $errors = [];

    $data_post = $data['post'];
    $post_id = $data['post_id'];


    foreach ($data_post as $k => $v) {

        switch ($k) {
            case 'pm_description':
                if ($v == '') {
                    $errors[$k] = 'Description không được rỗng';
                };

                break;
            case 'pm_start_date':
                if ($v == '') {
                    $errors[$k] = 'Start date không được rỗng';
                };
                break;
            case 'pm_end_date':

                if ($v == '') {
                    $errors[$k] = 'End date không được rỗng';
                };
                break;
            case 'pm_status':

                if ($v == '') {
                    $errors[$k] = 'Status không được rỗng';
                };
                break;
            case 'pm_size':
                if ($v == '') {
                    $errors[$k] = 'Team size không được rỗng';
                };
                if (!is_numeric($v)) {
                    $errors[$k] = 'Team size phải là số';
                };
                break;
        }
    }

    set_transient('validate_errors', $errors, 60);
    return $errors;
}

add_filter('filter_pm_validate_custom_metabox_errors', 'filter_pm_validate_custom_metabox');


function pm_save_meta_box($post_id, $post, $update)
{

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // If this is a revision, get real post ID.
    if ($parent_id = wp_is_post_revision($post_id)) {
        $post_id = $parent_id;
    }

    $temp = [
        'post' => $_POST,
        'post_id' => $post_id,
    ];

    $errors = apply_filters('filter_pm_validate_custom_metabox_errors', $temp);

    if (is_array($errors) && !is_null($errors) && !empty($errors)) {
        return;
    }

    foreach ($_POST as $k => $v) {
        update_post_meta($post_id, $k, sanitize_text_field($v));
    }
}

add_action('save_post', 'pm_save_meta_box', 10, 3);
