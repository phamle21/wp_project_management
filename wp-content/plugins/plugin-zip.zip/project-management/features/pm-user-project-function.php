<?php 



function custom_post_type_submenu()
{
    add_submenu_page(
        'edit.php?post_type=project', // slug của custom post type
        'Member lists', // tiêu đề của sub-menu
        'Members', // tên hiển thị của sub-menu
        'manage_options', // quyền truy cập cần thiết để truy cập vào sub-menu
        'member.php' // slug của trang hiển thị users
    );
}
add_action('admin_menu', 'custom_post_type_submenu');

?>