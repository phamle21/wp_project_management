<?php

if (!function_exists('create_project_post_type')) {

    function create_project_post_type()
    {
        $args = array(
            'labels' => array(
                'name' => __('Projects'),
                'singular_name' => __('Project'),
                'search_items' => __( 'Search Projects'),
                'view_item' => __( 'View Projects'),
                'not_found' =>  __( 'No project Found'),
                'new_item_name' => __('New project type'),
                'add_new_item' => __('Add new project'),
                'edit_item' => __('Update project information')
            ),
            'taxonomies' => array( 'project-type'),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'project'),
            'supports' => array('title', 'thumbnail'),
            'menu_icon' => 'dashicons-portfolio',
            'show_in_rest' => true,
        );
        register_post_type('project', $args);
    }
 
add_action('init', 'create_project_post_type');
}
?>