<div class="pm_box">
    <style scoped>
        .pm_box {
            display: grid;
            grid-template-columns: max-content 1fr;
            grid-row-gap: 10px;
            grid-column-gap: 20px;
        }

        .pm_field {
            display: contents;
        }
    </style>
    <?php  
        $errors = get_transient('validate_errors');
    ?>

    <p class="meta-options pm_field">
        <label for="pm_description">Description:</label>
        <input id="pm_description" value="<?php echo esc_attr(get_post_meta(get_the_ID(), 'pm_description', true)); ?>" type="text" name="pm_description">
    <p class="meta-options" style="height: 10px;text-align:center; color:red;">
        <?php echo (isset($errors['pm_description']) ? $errors['pm_description'] : '');  ?>
    </p>
    </p>
    <p class="meta-options pm_field">
        <label for="pm_start_date">Start Date: </label>
        <input id="pm_start_date" type="date" value="<?php echo esc_attr(get_post_meta(get_the_ID(), 'pm_start_date', true)); ?>" name="pm_start_date">
    <p class="meta-options" style="height: 10px;text-align:center; color:red;">
        <?php echo(isset($errors['pm_start_date']) ? $errors['pm_start_date'] : '');  ?>
    </p>
    </p>
    <p class="meta-options pm_field">End Date:</label>
        <input id="pm_end_date" type="date" value="<?php echo esc_attr(get_post_meta(get_the_ID(), 'pm_end_date', true)); ?>" name="pm_end_date">

    <p class="meta-options" style="height: 10px;text-align:center; color:red;">
       <?php echo(isset($errors['pm_end_date']) ? $errors['pm_end_date'] : '');  ?>
    </p>
    </p>

    <p class="meta-options pm_field">
        <label for="pm_size">Team size:</label>
        <input id="pm_size" type="text" name="pm_size" value="<?php echo esc_attr(get_post_meta(get_the_ID(), 'pm_size', true)); ?>">
    <p class="meta-options" style="height: 10px;text-align:center; color:red;">
        <?php echo(isset($errors['pm_size']) ? $errors['pm_size'] : '');  ?>
    </p>
    </p>
    <p class="meta-options pm_field">
        <label for="pm_status">Status:</label>
        <?php $value = get_post_meta(get_the_ID(), 'pm_status', true); ?>
        <select name="pm_status" id="pm_status">
            <option value="<?php echo PENDING ?>" <?php selected($value, PENDING) ?>><?php echo PENDING ?></option>
            <option value="<?php echo IN_PROGRESS ?>" <?php selected($value, IN_PROGRESS); ?>><?php echo IN_PROGRESS ?></option>
            <option value="<?php echo COMPLETED ?>" <?php selected($value, COMPLETED); ?>><?php echo COMPLETED ?></option>
        </select>
    <p class="meta-options" style="height: 10px;">
    </p>
    </p>
</div>

<script>
    
</script>