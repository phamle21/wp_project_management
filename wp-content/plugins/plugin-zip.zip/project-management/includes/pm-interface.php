<?php
    include plugin_dir_path(__FILE__) . '../features/pm-post-type-function.php';
    include plugin_dir_path(__FILE__) . '../features/pm-taxomony-function.php';
    include plugin_dir_path(__FILE__) . '../features/pm-metabox-function.php';
    include plugin_dir_path(__FILE__) . '../features/pm-user-project-function.php';
?>